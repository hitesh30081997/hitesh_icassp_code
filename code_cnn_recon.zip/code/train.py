"""
train.py
End-to-end training for the HuBERT SLURP SLU model.

Usage:
    python train.py \
        --slurp_jsonl_dir /path/to/slurp/dataset/slurp \
        --audio_root /path/to/slurp/audio \
        --output_dir ./ckpt \
        --hubert_name facebook/hubert-base-ls960 \
        --semantic_layer 8 \
        --epochs 20 --batch_size 8 --lr 3e-5

Noise-robust training with CNN-level reconstruction (noise disentanglement):
    python train.py \
        --slurp_jsonl_dir /path/to/slurp/dataset/slurp \
        --audio_root /path/to/slurp/audio \
        --noisy_audio_root /path/to/slurp_5dB/audio \
        --hubert_name microsoft/wavlm-base-plus \
        --recon_loss_weight 1.0 --recon_loss_type l1 \
        --output_dir ./ckpt_wavlm_5db_recon

  - The model is trained on the 5 dB audio (intent CE + CTC as before).
  - A frozen copy of the same WavLM's CNN encodes the paired CLEAN audio;
    the trainable CNN's output on the noisy audio (before feature_projection)
    is pulled towards it with --recon_loss_type.
  - The CNN feature encoder is unfrozen automatically (otherwise the
    reconstruction loss has nothing to train).
  - --recon_loss_weight 0 with --noisy_audio_root gives the plain
    noisy-training baseline for ablation.
"""
import argparse
import functools
import json
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from vocab import CTCVocab, build_label_maps, extract_slots_from_tagged_text
from dataset import SlurpDataset, collate_fn
from model import HubertSLUModel
from metrics import intent_accuracy, slu_f1
from denoise import FrozenCleanCNN, cnn_reconstruction_loss


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--slurp_jsonl_dir", required=True,
                    help="Directory containing train.jsonl / devel.jsonl / test.jsonl")
    p.add_argument("--audio_root", required=True,
                    help="CLEAN audio: directory containing slurp_real/ and slurp_synth/")
    p.add_argument("--noisy_audio_root", default=None,
                    help="NOISY (e.g. 5 dB) audio with the same layout/file names as "
                         "--audio_root. If given, the model is trained on it.")
    p.add_argument("--output_dir", default="./ckpt")
    p.add_argument("--hubert_name", default="facebook/hubert-base-ls960")
    p.add_argument("--semantic_layer", type=int, default=8,
                    help="Index into HuBERT hidden_states to read out (1..num_layers)")
    p.add_argument("--vocab_type", choices=["char", "bpe"], default="char",
                    help="CTC target granularity: char-level (vocab.CTCVocab) or "
                         "subword BPE (vocab_bpe.BPECTCVocab, trained from train.jsonl)")
    p.add_argument("--bpe_vocab_size", type=int, default=500,
                    help="Target BPE vocab size, only used when --vocab_type bpe")
    p.add_argument("--layer_fusion", choices=["single", "weighted_sum"], default="single",
                    help="'single': use hidden_states[semantic_layer] only. "
                         "'weighted_sum': learned SUPERB-style softmax-weighted sum "
                         "over --fusion_layers, with separate weights for the intent "
                         "and slot branches.")
    p.add_argument("--fusion_layers", type=str, default=None,
                    help="Comma-separated hidden_states indices to fuse over, e.g. "
                         "'4,6,8,10,12'. Only used when --layer_fusion weighted_sum. "
                         "Default: every Transformer block output (1..num_hidden_layers).")
    p.add_argument("--freeze_feature_extractor", action=argparse.BooleanOptionalAction,
                    default=None,
                    help="Freeze the CNN feature encoder. Default: frozen, unless "
                         "--recon_loss_weight > 0 (then it must be trainable).")
    # --- noise disentanglement at the CNN output ---
    p.add_argument("--recon_loss_weight", type=float, default=1.0,
                    help="Weight of the CNN reconstruction loss (noisy student CNN vs "
                         "frozen clean teacher CNN). Only active with --noisy_audio_root. "
                         "0 disables it.")
    p.add_argument("--recon_loss_type", choices=["l1", "mse", "cosine", "l1_cosine"],
                    default="l1")
    p.add_argument("--recon_feat_norm", choices=["none", "layernorm"], default="none",
                    help="'layernorm': parameter-free per-frame LayerNorm on both CNN "
                         "outputs before the distance (scale-invariant).")
    p.add_argument("--cnn_lr", type=float, default=None,
                    help="LR for the CNN feature encoder (default: --lr).")
    p.add_argument("--clean_prob", type=float, default=0.0,
                    help="Fraction of training examples fed as CLEAN input instead of "
                         "noisy (target stays clean). 0 = always noisy.")
    p.add_argument("--select_on", choices=["noisy", "clean"], default="noisy",
                    help="Which dev set's SLU-F1 picks best_model.pt.")
    p.add_argument("--freeze_encoder_layers", type=int, default=0,
                    help="Freeze the first N Transformer blocks (<= semantic_layer makes sense)")
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--lr", type=float, default=3e-5)
    p.add_argument("--ctc_loss_weight", type=float, default=1.0)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--max_audio_seconds", type=float, default=15.0)
    p.add_argument("--grad_clip", type=float, default=5.0)
    p.add_argument("--log_every", type=int, default=50)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return p.parse_args()


def build_or_load_vocabs(args, out_dir):
    intent_map_path = out_dir / "intent_labels.json"
    train_jsonl = Path(args.slurp_jsonl_dir) / "train.jsonl"

    if args.vocab_type == "bpe":
        from vocab_bpe import BPECTCVocab, build_bpe_vocab_from_jsonl
        ctc_vocab_path = out_dir / "bpe_tokenizer.json"
        if intent_map_path.exists() and ctc_vocab_path.exists():
            intent_list = json.loads(intent_map_path.read_text())
            ctc_vocab = BPECTCVocab.load(ctc_vocab_path)
        else:
            intent_list, _ = build_label_maps([train_jsonl])
            out_dir.mkdir(parents=True, exist_ok=True)
            intent_map_path.write_text(json.dumps(intent_list, indent=2))
            ctc_vocab = build_bpe_vocab_from_jsonl(
                [train_jsonl], vocab_size=args.bpe_vocab_size, save_path=ctc_vocab_path
            )
    else:
        ctc_vocab_path = out_dir / "ctc_vocab.json"
        if intent_map_path.exists() and ctc_vocab_path.exists():
            intent_list = json.loads(intent_map_path.read_text())
            ctc_vocab = CTCVocab.load(ctc_vocab_path)
        else:
            intent_list, slot_types = build_label_maps([train_jsonl])
            ctc_vocab = CTCVocab(slot_types)
            out_dir.mkdir(parents=True, exist_ok=True)
            intent_map_path.write_text(json.dumps(intent_list, indent=2))
            ctc_vocab.save(ctc_vocab_path)

    intent2id = {label: i for i, label in enumerate(intent_list)}
    return intent_list, intent2id, ctc_vocab


@torch.no_grad()
def evaluate(model, loader, device, ctc_vocab, intent_list):
    model.eval()
    pred_intents, gold_intents = [], []
    pred_texts, gold_texts = [], []
    for batch in loader:
        batch = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}
        outputs = model(batch["input_values"], batch["attention_mask"])

        pred_intents.extend(outputs["intent_logits"].argmax(-1).tolist())
        gold_intents.extend(batch["intent_ids"].tolist())

        greedy_ids = outputs["ctc_log_probs"].argmax(-1).transpose(0, 1).tolist()  # (B, T)
        feat_lens = outputs["feat_lens"].tolist()
        for ids, L in zip(greedy_ids, feat_lens):
            pred_texts.append(ctc_vocab.decode(ids[:L]))
        gold_texts.extend(batch["tagged_texts"])

    acc = intent_accuracy(pred_intents, gold_intents)
    f1 = slu_f1(pred_texts, gold_texts)
    model.train()
    return {"intent_accuracy": acc, **f1}


def main():
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    use_noisy = args.noisy_audio_root is not None
    use_recon = use_noisy and args.recon_loss_weight > 0
    if args.recon_loss_weight > 0 and not use_noisy:
        print("[recon] --noisy_audio_root not given -> reconstruction loss disabled")
    if args.freeze_feature_extractor is None:
        args.freeze_feature_extractor = not use_recon
    if use_recon and args.freeze_feature_extractor:
        raise ValueError("--recon_loss_weight > 0 needs a trainable CNN; "
                         "drop --freeze_feature_extractor.")
    (out_dir / "train_args.json").write_text(json.dumps(vars(args), indent=2))

    intent_list, intent2id, ctc_vocab = build_or_load_vocabs(args, out_dir)
    print(f"[vocab] {len(intent_list)} intents, {len(ctc_vocab)} CTC symbols")

    jsonl_dir = Path(args.slurp_jsonl_dir)
    train_input_root = args.noisy_audio_root if use_noisy else args.audio_root
    need_clean_pair = use_noisy and (use_recon or args.clean_prob > 0)
    train_ds = SlurpDataset(
        jsonl_dir / "train.jsonl", train_input_root,
        ctc_vocab, intent2id, args.max_audio_seconds,
        clean_audio_root=args.audio_root if need_clean_pair else None,
        clean_prob=args.clean_prob if use_noisy else 0.0,
    )
    # Dev sets: always clean; plus noisy when training on noisy audio.
    dev_sets = {"clean": SlurpDataset(jsonl_dir / "devel.jsonl", args.audio_root,
                                      ctc_vocab, intent2id, args.max_audio_seconds)}
    if use_noisy:
        dev_sets["noisy"] = SlurpDataset(jsonl_dir / "devel.jsonl", args.noisy_audio_root,
                                         ctc_vocab, intent2id, args.max_audio_seconds)
    select_on = args.select_on if args.select_on in dev_sets else "clean"
    print(f"[data] train={len(train_ds)} (input={'noisy' if use_noisy else 'clean'}, "
          f"paired clean={need_clean_pair}) "
          + " ".join(f"dev_{k}={len(v)}" for k, v in dev_sets.items()))

    collate = functools.partial(collate_fn, pad_id=ctc_vocab.pad_id)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                               num_workers=args.num_workers, collate_fn=collate)
    dev_loaders = {k: DataLoader(v, batch_size=args.batch_size, shuffle=False,
                                 num_workers=args.num_workers, collate_fn=collate)
                   for k, v in dev_sets.items()}

    model = HubertSLUModel(
        num_intents=len(intent_list),
        ctc_vocab_size=len(ctc_vocab),
        pad_id=ctc_vocab.pad_id,
        blank_id=ctc_vocab.blank_id,
        hubert_name=args.hubert_name,
        semantic_layer=args.semantic_layer,
        layer_fusion=args.layer_fusion,
        fusion_layers=([int(x) for x in args.fusion_layers.split(",")]
                       if args.fusion_layers else None),
        freeze_feature_extractor=args.freeze_feature_extractor,
        freeze_encoder_layers=args.freeze_encoder_layers,
    )
    model.to(args.device)

    teacher_cnn = None
    if use_recon:
        # Frozen CNN of the SAME pretrained checkpoint -> clean target features.
        teacher_cnn = FrozenCleanCNN(args.hubert_name).to(args.device)
        print(f"[recon] frozen clean CNN teacher from {args.hubert_name}; "
              f"loss={args.recon_loss_type}, norm={args.recon_feat_norm}, "
              f"weight={args.recon_loss_weight}")

    cnn_param_ids = {id(p) for p in model.hubert.feature_extractor.parameters()}
    cnn_params = [p for p in model.hubert.feature_extractor.parameters() if p.requires_grad]
    encoder_params = [p for p in model.hubert.parameters()
                      if p.requires_grad and id(p) not in cnn_param_ids]
    head_modules = [model.intent_pool, model.intent_head, model.slot_lstm, model.ctc_head]
    if args.layer_fusion == "weighted_sum":
        head_modules += [model.intent_layer_fusion, model.slot_layer_fusion]
    if getattr(model, "_normalize_feats", False):
        head_modules.append(model.feat_norm)
    head_params = [p for m in head_modules for p in m.parameters() if p.requires_grad]
    cnn_lr = args.cnn_lr if args.cnn_lr is not None else args.lr

    head_lr = args.lr * 20  # heads (incl. layer-fusion weights) are randomly
                             # initialized and need a much bigger LR than the
                             # pretrained encoder to actually move within a
                             # normal training budget.
    groups = [(encoder_params, args.lr), (head_params, head_lr)]
    if cnn_params:
        groups.append((cnn_params, cnn_lr))
    optimizer = torch.optim.AdamW([{"params": ps, "lr": lr} for ps, lr in groups])
    total_steps = args.epochs * len(train_loader)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer, max_lr=[lr for _, lr in groups], total_steps=max(1, total_steps)
    )
    print(f"[optim] encoder lr={args.lr}, head lr={head_lr}, cnn lr={cnn_lr}, "
          f"encoder params={sum(p.numel() for p in encoder_params):,}, "
          f"cnn params={sum(p.numel() for p in cnn_params):,}, "
          f"head params={sum(p.numel() for p in head_params):,}")

    best_f1 = -1.0
    step = 0
    for epoch in range(args.epochs):
        model.train()
        pbar = tqdm(train_loader, desc=f"epoch {epoch}")
        for batch in pbar:
            batch = {k: (v.to(args.device) if torch.is_tensor(v) else v) for k, v in batch.items()}
            outputs = model(batch["input_values"], batch["attention_mask"])
            loss, intent_loss, ctc_loss = model.compute_loss(
                batch, outputs, ctc_loss_weight=args.ctc_loss_weight
            )
            recon_loss = None
            if use_recon:
                clean_cnn = teacher_cnn(batch["clean_values"])      # (B, T, C), no grad
                recon_loss = cnn_reconstruction_loss(
                    outputs["cnn_feats"], clean_cnn, outputs["cnn_frame_mask"],
                    loss_type=args.recon_loss_type, feat_norm=args.recon_feat_norm,
                )
                loss = loss + args.recon_loss_weight * recon_loss

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            optimizer.step()
            scheduler.step()

            step += 1
            if step % args.log_every == 0:
                postfix = dict(loss=float(loss.detach()), intent=float(intent_loss),
                               ctc=float(ctc_loss))
                if recon_loss is not None:
                    postfix["recon"] = float(recon_loss.detach())
                pbar.set_postfix(**postfix)

        all_metrics = {}
        for name, loader in dev_loaders.items():
            m = evaluate(model, loader, args.device, ctc_vocab, intent_list)
            all_metrics[name] = m
            print(f"[epoch {epoch}] dev_{name} intent_acc={m['intent_accuracy']:.4f} "
                  f"slu_f1={m['f1']:.4f} (P={m['precision']:.4f} R={m['recall']:.4f})")
        metrics = all_metrics[select_on]

        fusion_weights = model.log_layer_fusion_weights()
        if fusion_weights is not None:
            print(f"[epoch {epoch}] layer fusion weights (layers={fusion_weights['layers']})")
            print(f"    intent: {[round(w, 3) for w in fusion_weights['intent']]}")
            print(f"    slot  : {[round(w, 3) for w in fusion_weights['slot']]}")

        if metrics["f1"] > best_f1:
            best_f1 = metrics["f1"]
            torch.save(model.state_dict(), out_dir / "best_model.pt")
            print(f"[epoch {epoch}] new best model saved "
                  f"(dev_{select_on} slu_f1={best_f1:.4f})")

    torch.save(model.state_dict(), out_dir / "last_model.pt")


if __name__ == "__main__":
    main()
