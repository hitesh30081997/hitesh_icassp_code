"""
train.py
End-to-end training for the HuBERT SLURP SLU model.

Usage:
    python train.py \
        --slurp_jsonl_dir /path/to/slurp/dataset/slurp \
        --audio_root /path/to/slurp/audio \
        --output_dir ./ckpt \
        --hubert_name facebook/hubert-base-ls960 \
        --semantic_layer 8 \
        --epochs 20 --batch_size 8 --lr 3e-5

RNN-T slot decoder warm-started from NVIDIA Nemotron (instead of BiLSTM+CTC):
    python export_nemotron_decoder.py --out_dir ./nemotron_rnnt   # once, needs NeMo
    python train.py ... --slot_decoder rnnt --vocab_type nemotron \
        --nemotron_dir ./nemotron_rnnt --rnnt_frame_stack 2
"""
import argparse
import functools
import json
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from vocab import CTCVocab, build_label_maps, extract_slots_from_tagged_text
from dataset import SlurpDataset, collate_fn
from model import HubertSLUModel
from metrics import intent_accuracy, slu_f1


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--slurp_jsonl_dir", required=True,
                    help="Directory containing train.jsonl / devel.jsonl / test.jsonl")
    p.add_argument("--audio_root", required=True,
                    help="Directory containing slurp_real/ and slurp_synth/")
    p.add_argument("--output_dir", default="./ckpt")
    p.add_argument("--hubert_name", default="facebook/hubert-base-ls960")
    p.add_argument("--semantic_layer", type=int, default=8,
                    help="Index into HuBERT hidden_states to read out (1..num_layers)")
    p.add_argument("--vocab_type", choices=["char", "bpe", "nemotron"], default="char",
                    help="Target granularity: char-level (vocab.CTCVocab), "
                         "subword BPE (vocab_bpe.BPECTCVocab, trained from train.jsonl), or "
                         "the Nemotron SentencePiece tokenizer + slot tags "
                         "(vocab_nemotron.NemotronSlotVocab; needed to warm-start the "
                         "Nemotron RNN-T decoder)")
    p.add_argument("--slot_decoder", choices=["ctc", "rnnt"], default="ctc",
                    help="'ctc': BiLSTM + CTC (original). 'rnnt': RNN-Transducer "
                         "prediction+joint network (Nemotron/NeMo layout).")
    p.add_argument("--nemotron_dir", default=None,
                    help="Output dir of export_nemotron_decoder.py (decoder_joint.pt, "
                         "config.json, tokenizer.model)")
    p.add_argument("--no_rnnt_warm_start", action="store_true",
                    help="With --nemotron_dir: use its tokenizer/dims but train the "
                         "RNN-T decoder from scratch")
    p.add_argument("--rnnt_frame_stack", type=int, default=2,
                    help="Stack k HuBERT frames (20 ms) before the joint; 2 -> 40 ms. "
                         "Cuts RNN-T memory/time by ~k.")
    p.add_argument("--rnnt_pred_hidden", type=int, default=640)
    p.add_argument("--rnnt_pred_layers", type=int, default=1)
    p.add_argument("--rnnt_joint_hidden", type=int, default=640)
    p.add_argument("--rnnt_dropout", type=float, default=0.2)
    p.add_argument("--rnnt_max_symbols", type=int, default=10,
                    help="Max tokens emitted per frame in greedy decoding")
    p.add_argument("--rnnt_loss_backend", choices=["auto", "torchaudio", "nemo"], default="auto")
    p.add_argument("--pretrained_dec_lr", type=float, default=None,
                    help="LR for warm-started Nemotron decoder params (default: 5 x --lr)")
    p.add_argument("--bpe_vocab_size", type=int, default=500,
                    help="Target BPE vocab size, only used when --vocab_type bpe")
    p.add_argument("--layer_fusion", choices=["single", "weighted_sum"], default="single",
                    help="'single': use hidden_states[semantic_layer] only. "
                         "'weighted_sum': learned SUPERB-style softmax-weighted sum "
                         "over --fusion_layers, with separate weights for the intent "
                         "and slot branches.")
    p.add_argument("--fusion_layers", type=str, default=None,
                    help="Comma-separated hidden_states indices to fuse over, e.g. "
                         "'4,6,8,10,12'. Only used when --layer_fusion weighted_sum. "
                         "Default: every Transformer block output (1..num_hidden_layers).")
    p.add_argument("--freeze_feature_extractor", action="store_true", default=True)
    p.add_argument("--freeze_encoder_layers", type=int, default=0,
                    help="Freeze the first N Transformer blocks (<= semantic_layer makes sense)")
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--lr", type=float, default=3e-5)
    p.add_argument("--ctc_loss_weight", type=float, default=1.0)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--max_audio_seconds", type=float, default=15.0)
    p.add_argument("--grad_clip", type=float, default=5.0)
    p.add_argument("--log_every", type=int, default=50)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return p.parse_args()


def build_or_load_vocabs(args, out_dir):
    intent_map_path = out_dir / "intent_labels.json"
    train_jsonl = Path(args.slurp_jsonl_dir) / "train.jsonl"

    if args.vocab_type == "nemotron":
        from vocab_nemotron import NemotronSlotVocab
        if intent_map_path.exists() and NemotronSlotVocab.exists(out_dir):
            intent_list = json.loads(intent_map_path.read_text())
            ctc_vocab = NemotronSlotVocab.load(out_dir)
        else:
            if not args.nemotron_dir:
                raise ValueError("--vocab_type nemotron requires --nemotron_dir")
            intent_list, slot_types = build_label_maps([train_jsonl])
            out_dir.mkdir(parents=True, exist_ok=True)
            intent_map_path.write_text(json.dumps(intent_list, indent=2))
            ctc_vocab = NemotronSlotVocab(Path(args.nemotron_dir) / "tokenizer.model", slot_types)
            ctc_vocab.save(out_dir)
    elif args.vocab_type == "bpe":
        from vocab_bpe import BPECTCVocab, build_bpe_vocab_from_jsonl
        ctc_vocab_path = out_dir / "bpe_tokenizer.json"
        if intent_map_path.exists() and ctc_vocab_path.exists():
            intent_list = json.loads(intent_map_path.read_text())
            ctc_vocab = BPECTCVocab.load(ctc_vocab_path)
        else:
            intent_list, _ = build_label_maps([train_jsonl])
            out_dir.mkdir(parents=True, exist_ok=True)
            intent_map_path.write_text(json.dumps(intent_list, indent=2))
            ctc_vocab = build_bpe_vocab_from_jsonl(
                [train_jsonl], vocab_size=args.bpe_vocab_size, save_path=ctc_vocab_path
            )
    else:
        ctc_vocab_path = out_dir / "ctc_vocab.json"
        if intent_map_path.exists() and ctc_vocab_path.exists():
            intent_list = json.loads(intent_map_path.read_text())
            ctc_vocab = CTCVocab.load(ctc_vocab_path)
        else:
            intent_list, slot_types = build_label_maps([train_jsonl])
            ctc_vocab = CTCVocab(slot_types)
            out_dir.mkdir(parents=True, exist_ok=True)
            intent_map_path.write_text(json.dumps(intent_list, indent=2))
            ctc_vocab.save(ctc_vocab_path)

    intent2id = {label: i for i, label in enumerate(intent_list)}
    return intent_list, intent2id, ctc_vocab


@torch.no_grad()
def evaluate(model, loader, device, ctc_vocab, intent_list):
    model.eval()
    pred_intents, gold_intents = [], []
    pred_texts, gold_texts = [], []
    for batch in loader:
        batch = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}
        outputs = model(batch["input_values"], batch["attention_mask"])

        pred_intents.extend(outputs["intent_logits"].argmax(-1).tolist())
        gold_intents.extend(batch["intent_ids"].tolist())

        pred_texts.extend(model.decode_slots(outputs, ctc_vocab))
        gold_texts.extend(batch["tagged_texts"])

    acc = intent_accuracy(pred_intents, gold_intents)
    f1 = slu_f1(pred_texts, gold_texts)
    model.train()
    return {"intent_accuracy": acc, **f1}


def build_rnnt_cfg(args):
    """RNNTSlotHead kwargs. Dims come from the Nemotron export when given,
    so pretrained weights fit exactly."""
    cfg = dict(
        frame_stack=args.rnnt_frame_stack,
        pred_hidden=args.rnnt_pred_hidden,
        pred_layers=args.rnnt_pred_layers,
        joint_hidden=args.rnnt_joint_hidden,
        dropout=args.rnnt_dropout,
        max_symbols_per_step=args.rnnt_max_symbols,
        loss_backend=args.rnnt_loss_backend,
    )
    if args.nemotron_dir:
        from rnnt_head import RNNTSlotHead
        n = RNNTSlotHead.read_nemotron_config(args.nemotron_dir)
        cfg.update(
            pred_hidden=n["pred_hidden"], pred_layers=n["pred_layers"],
            pred_proj=n.get("pred_proj", 0), pred_embed=n["pred_embed_dim"],
            joint_hidden=n["joint_hidden"], joint_activation=n["joint_activation"],
        )
    return cfg


def main():
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    intent_list, intent2id, ctc_vocab = build_or_load_vocabs(args, out_dir)
    print(f"[vocab] {len(intent_list)} intents, {len(ctc_vocab)} output symbols "
          f"({args.vocab_type}, slot decoder={args.slot_decoder})")

    train_ds = SlurpDataset(
        Path(args.slurp_jsonl_dir) / "train.jsonl", args.audio_root,
        ctc_vocab, intent2id, args.max_audio_seconds,
    )
    dev_ds = SlurpDataset(
        Path(args.slurp_jsonl_dir) / "devel.jsonl", args.audio_root,
        ctc_vocab, intent2id, args.max_audio_seconds,
    )
    print(f"[data] train={len(train_ds)} dev={len(dev_ds)}")

    collate = functools.partial(collate_fn, pad_id=ctc_vocab.pad_id)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                               num_workers=args.num_workers, collate_fn=collate)
    dev_loader = DataLoader(dev_ds, batch_size=args.batch_size, shuffle=False,
                             num_workers=args.num_workers, collate_fn=collate)

    model_kwargs = dict(
        num_intents=len(intent_list),
        ctc_vocab_size=len(ctc_vocab),
        pad_id=ctc_vocab.pad_id,
        blank_id=ctc_vocab.blank_id,
        hubert_name=args.hubert_name,
        semantic_layer=args.semantic_layer,
        layer_fusion=args.layer_fusion,
        fusion_layers=([int(x) for x in args.fusion_layers.split(",")]
                       if args.fusion_layers else None),
        freeze_feature_extractor=args.freeze_feature_extractor,
        freeze_encoder_layers=args.freeze_encoder_layers,
        slot_decoder=args.slot_decoder,
        rnnt_cfg=build_rnnt_cfg(args) if args.slot_decoder == "rnnt" else None,
    )
    # everything infer.py needs to rebuild the exact same model
    (out_dir / "run_config.json").write_text(json.dumps(
        {"vocab_type": args.vocab_type, "model_kwargs": model_kwargs}, indent=2))

    model = HubertSLUModel(**model_kwargs)
    if args.slot_decoder == "rnnt" and args.nemotron_dir and not args.no_rnnt_warm_start:
        if args.vocab_type != "nemotron":
            raise ValueError("Warm-starting the Nemotron decoder needs --vocab_type nemotron "
                             "(its embedding/output rows are tied to the Nemotron tokenizer). "
                             "Pass --no_rnnt_warm_start to train from scratch instead.")
        n_cfg = model.slot_head.read_nemotron_config(args.nemotron_dir)
        model.slot_head.load_nemotron_pretrained(
            args.nemotron_dir, ctc_vocab.pretrained_index_map(n_cfg["text_vocab_size"]))
    model.to(args.device)

    # Three param groups: pretrained speech encoder (small LR), warm-started
    # Nemotron decoder weights (medium LR, so we adapt rather than erase them),
    # everything else = randomly initialized heads (large LR).
    pretrained_dec = model.pretrained_head_param_names()
    encoder_params, dec_params, head_params = [], [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if name.startswith("hubert."):
            encoder_params.append(p)
        elif name in pretrained_dec:
            dec_params.append(p)
        else:
            head_params.append(p)

    head_lr = args.lr * 20  # heads (incl. layer-fusion weights) are randomly
                             # initialized and need a much bigger LR than the
                             # pretrained encoder to actually move within a
                             # normal training budget.
    dec_lr = args.pretrained_dec_lr or args.lr * 5
    groups, max_lrs = [], []
    for params, lr in ((encoder_params, args.lr), (dec_params, dec_lr), (head_params, head_lr)):
        if params:
            groups.append({"params": params, "lr": lr})
            max_lrs.append(lr)
    optimizer = torch.optim.AdamW(groups)
    total_steps = args.epochs * len(train_loader)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer, max_lr=max_lrs, total_steps=max(1, total_steps)
    )
    print(f"[optim] encoder lr={args.lr}, pretrained-decoder lr={dec_lr}, head lr={head_lr}, "
          f"encoder params={sum(p.numel() for p in encoder_params):,}, "
          f"pretrained-decoder params={sum(p.numel() for p in dec_params):,}, "
          f"head params={sum(p.numel() for p in head_params):,}")

    best_f1 = -1.0
    step = 0
    for epoch in range(args.epochs):
        model.train()
        pbar = tqdm(train_loader, desc=f"epoch {epoch}")
        for batch in pbar:
            batch = {k: (v.to(args.device) if torch.is_tensor(v) else v) for k, v in batch.items()}
            outputs = model(batch["input_values"], batch["attention_mask"])
            loss, intent_loss, slot_loss = model.compute_loss(
                batch, outputs, ctc_loss_weight=args.ctc_loss_weight
            )

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            optimizer.step()
            scheduler.step()

            step += 1
            if step % args.log_every == 0:
                pbar.set_postfix(loss=float(loss.detach()), intent=float(intent_loss),
                                 **{args.slot_decoder: float(slot_loss)})
        metrics = evaluate(model, dev_loader, args.device, ctc_vocab, intent_list)
        print(f"[epoch {epoch}] dev intent_acc={metrics['intent_accuracy']:.4f} "
              f"slu_f1={metrics['f1']:.4f} (P={metrics['precision']:.4f} R={metrics['recall']:.4f})")

        fusion_weights = model.log_layer_fusion_weights()
        if fusion_weights is not None:
            print(f"[epoch {epoch}] layer fusion weights (layers={fusion_weights['layers']})")
            print(f"    intent: {[round(w, 3) for w in fusion_weights['intent']]}")
            print(f"    slot  : {[round(w, 3) for w in fusion_weights['slot']]}")

        if metrics["f1"] > best_f1:
            best_f1 = metrics["f1"]
            torch.save(model.state_dict(), out_dir / "best_model.pt")
            print(f"[epoch {epoch}] new best model saved (slu_f1={best_f1:.4f})")

    torch.save(model.state_dict(), out_dir / "last_model.pt")


if __name__ == "__main__":
    main()
