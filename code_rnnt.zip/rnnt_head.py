"""
rnnt_head.py
RNN-Transducer slot-filling head that replaces the BiLSTM + CTC branch.

Architecture (mirrors NVIDIA NeMo's RNNTDecoder + RNNTJoint, i.e. the
decoder used by nvidia/nemotron-speech-streaming-en-0.6b and the Parakeet
RNNT models, so pretrained weights can be copied 1:1):

    HuBERT/WavLM frames (B, T, H)
        -> frame stacking x k  (50 Hz -> 25 Hz for k=2; RNNT memory is
                                O(T * U * V), so this matters a lot)
        -> LayerNorm
        -> joint.enc   : Linear(k*H, J)                       [always new]
    tagged-transcript tokens (B, U)
        -> [blank] + tokens  (blank doubles as SOS, "blank_as_pad")
        -> prediction.embed : Embedding(V, P, padding_idx=blank)
        -> prediction.lstm  : LSTM(P, P, num_layers)
        -> joint.pred  : Linear(P, J)
    joint: out( dropout( relu( enc[:, :, None] + pred[:, None] ) ) )
        -> logits (B, T', U+1, V)  -> RNN-T loss

Unlike CTC, the prediction network is an autoregressive label LM, so the
model can learn "after <fill_time> comes 'five am' then <end_fill>" --
exactly the kind of structure that CTC's conditional-independence
assumption can't express.

Warm start: `load_nemotron_pretrained()` copies the prediction network and
the joint's pred/out layers from a directory written by
export_nemotron_decoder.py. joint.enc is always re-initialized because the
acoustic features now come from HuBERT, not the FastConformer encoder.
"""
import json
import warnings
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------------------------------------------------------------
# RNN-T loss backends
# --------------------------------------------------------------------------
def _pick_loss_backend(preferred="auto"):
    if preferred in ("auto", "torchaudio"):
        try:
            import torchaudio
            if hasattr(torchaudio.functional, "rnnt_loss"):
                return "torchaudio"
        except Exception:
            pass
        if preferred == "torchaudio":
            raise RuntimeError("torchaudio.functional.rnnt_loss is not available")
    try:
        from nemo.collections.asr.losses.rnnt import RNNTLoss  # noqa: F401
        return "nemo"
    except Exception as e:
        raise RuntimeError(
            "No RNN-T loss available. Install a torchaudio version that still "
            "ships functional.rnnt_loss, or `pip install nemo_toolkit[asr]`."
        ) from e


# --------------------------------------------------------------------------
# Building blocks
# --------------------------------------------------------------------------
class PredictionNetwork(nn.Module):
    """NeMo-style RNN-T prediction net: Embedding -> LSTM. The blank id is
    used both as SOS input and as padding_idx (zero embedding)."""

    def __init__(self, vocab_size, blank_id, embed_dim=640, hidden=640,
                 num_layers=1, proj_size=0, dropout=0.2):
        super().__init__()
        self.blank_id = blank_id
        self.embed = nn.Embedding(vocab_size, embed_dim, padding_idx=blank_id)
        self.lstm = nn.LSTM(
            input_size=embed_dim, hidden_size=hidden, num_layers=num_layers,
            proj_size=proj_size, batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.out_dim = proj_size if proj_size > 0 else hidden

    def forward(self, targets):
        """Teacher-forced pass. targets: (B, U) -> (B, U+1, P)."""
        B = targets.shape[0]
        sos = targets.new_full((B, 1), self.blank_id)
        y = torch.cat([sos, targets], dim=1)
        out, _ = self.lstm(self.embed(y))
        return out

    def step(self, tokens, state):
        """One autoregressive step. tokens: (B,) -> out (B, P), new state."""
        out, state = self.lstm(self.embed(tokens).unsqueeze(1), state)
        return out.squeeze(1), state


class JointNetwork(nn.Module):
    def __init__(self, enc_dim, pred_dim, joint_hidden, vocab_size,
                 activation="relu", dropout=0.2):
        super().__init__()
        self.enc = nn.Linear(enc_dim, joint_hidden)
        self.pred = nn.Linear(pred_dim, joint_hidden)
        self.act = {"relu": nn.ReLU(), "tanh": nn.Tanh(),
                    "sigmoid": nn.Sigmoid()}[activation.lower()]
        self.dropout = nn.Dropout(dropout)
        self.out = nn.Linear(joint_hidden, vocab_size)

    def combine(self, f, g):
        """f, g already projected to joint_hidden; broadcastable shapes."""
        return self.out(self.dropout(self.act(f + g)))

    def forward(self, enc, pred):
        # enc: (B, T, E), pred: (B, U+1, P) -> (B, T, U+1, V)
        f = self.enc(enc).unsqueeze(2)
        g = self.pred(pred).unsqueeze(1)
        return self.combine(f, g)


# --------------------------------------------------------------------------
# Full head
# --------------------------------------------------------------------------
class RNNTSlotHead(nn.Module):
    def __init__(self, input_dim, vocab_size, blank_id,
                 frame_stack=2, pred_hidden=640, pred_layers=1, pred_proj=0,
                 pred_embed=None,
                 joint_hidden=640, joint_activation="relu", dropout=0.2,
                 max_symbols_per_step=10, loss_backend="auto"):
        super().__init__()
        self.vocab_size = vocab_size
        self.blank_id = blank_id
        self.frame_stack = max(1, int(frame_stack))
        self.max_symbols = max_symbols_per_step
        self._loss_backend_pref = loss_backend
        self._loss_backend = None   # resolved lazily
        self._nemo_loss = None

        enc_in = input_dim * self.frame_stack
        self.enc_norm = nn.LayerNorm(enc_in)
        self.prediction = PredictionNetwork(
            vocab_size, blank_id, embed_dim=pred_embed or pred_hidden, hidden=pred_hidden,
            num_layers=pred_layers, proj_size=pred_proj, dropout=dropout,
        )
        self.joint = JointNetwork(
            enc_in, self.prediction.out_dim, joint_hidden, vocab_size,
            activation=joint_activation, dropout=dropout,
        )
        # names (relative to this module) of params warm-started from Nemotron,
        # so train.py can give them a gentler learning rate
        self.pretrained_param_names = set()

    # ---------------- encoder-side preprocessing ----------------
    def prepare_encoder(self, feats, feat_lens):
        """Stack k consecutive frames: (B, T, H) -> (B, ceil(T/k), k*H)."""
        k = self.frame_stack
        if k > 1:
            B, T, H = feats.shape
            pad = (-T) % k
            if pad:
                feats = F.pad(feats, (0, 0, 0, pad))
            feats = feats.reshape(B, (T + pad) // k, k * H)
            feat_lens = torch.div(feat_lens + k - 1, k, rounding_mode="floor")
        return self.enc_norm(feats), feat_lens

    # ---------------- training ----------------
    def loss(self, enc, enc_lens, targets, target_lens):
        """enc: (B, T', E) from prepare_encoder. Returns per-token-normalized
        RNN-T loss averaged over the batch (same scale convention as
        F.ctc_loss(reduction='mean'), so ctc_loss_weight keeps its meaning)."""
        U = int(target_lens.max().item())
        targets = targets[:, :U]
        # padded positions may hold ids that are invalid for the loss
        # (e.g. pad == blank); they're masked by target_lens anyway.
        valid = torch.arange(U, device=targets.device)[None] < target_lens[:, None]
        targets = torch.where(valid, targets, torch.zeros_like(targets))
        if self.blank_id == 0:
            targets = torch.where(valid, targets, torch.ones_like(targets))

        T = int(enc_lens.max().item())
        enc = enc[:, :T]
        pred = self.prediction(targets)                  # (B, U+1, P)
        logits = self.joint(enc, pred).float()           # (B, T, U+1, V)

        if self._loss_backend is None:
            self._loss_backend = _pick_loss_backend(self._loss_backend_pref)

        if self._loss_backend == "torchaudio":
            import torchaudio
            per_utt = torchaudio.functional.rnnt_loss(
                logits, targets.int(), enc_lens.int(), target_lens.int(),
                blank=self.blank_id, reduction="none",
            )
        else:
            per_utt = self._nemo_rnnt_loss(logits, targets, enc_lens, target_lens)

        per_utt = per_utt / target_lens.clamp(min=1).float()
        return per_utt.mean()

    def _nemo_rnnt_loss(self, logits, targets, enc_lens, target_lens):
        from nemo.collections.asr.losses.rnnt import RNNTLoss
        b = self.blank_id
        V = self.vocab_size
        if self._nemo_loss is None:
            # NeMo requires blank == last index (== num_classes)
            self._nemo_loss = RNNTLoss(num_classes=V - 1, reduction=None)
        if b != V - 1:  # move blank to the end
            logits = torch.cat([logits[..., :b], logits[..., b + 1:], logits[..., b:b + 1]], -1)
            targets = torch.where(targets > b, targets - 1, targets)
        return self._nemo_loss(
            log_probs=torch.log_softmax(logits, -1), targets=targets.long(),
            input_lengths=enc_lens.long(), target_lengths=target_lens.long(),
        )

    # ---------------- inference ----------------
    @torch.no_grad()
    def greedy_decode(self, enc, enc_lens):
        """Batched greedy RNN-T decoding. Returns list[list[int]] (no blanks,
        no CTC-style collapsing -- use vocab.decode_tokens on the result)."""
        B, T, _ = enc.shape
        f_all = self.joint.enc(enc)                              # (B, T, J)
        hyps = [[] for _ in range(B)]
        last = torch.full((B,), self.blank_id, dtype=torch.long, device=enc.device)
        p, state = self.prediction.step(last, None)
        g = self.joint.pred(p)                                   # (B, J)

        for t in range(T):
            f = f_all[:, t]
            active = t < enc_lens
            for _ in range(self.max_symbols):
                k = self.joint.combine(f, g).argmax(-1)          # (B,)
                emit = active & (k != self.blank_id)
                if not emit.any():
                    break
                p_new, state_new = self.prediction.step(k, state)
                g = torch.where(emit[:, None], self.joint.pred(p_new), g)
                m = emit[None, :, None]
                state = tuple(torch.where(m, sn, so) for sn, so in zip(state_new, state))
                for b in emit.nonzero(as_tuple=True)[0].tolist():
                    hyps[b].append(int(k[b]))
                active = emit   # only items that just emitted stay on frame t
        return hyps

    # ---------------- warm start from Nemotron ----------------
    def load_nemotron_pretrained(self, export_dir, index_map):
        """Copy prediction net + joint.pred + joint.out from an export made by
        export_nemotron_decoder.py.

        index_map: LongTensor (V_new,) -- for each id in *our* vocab, the row
        in the pretrained vocab (incl. its blank) to copy, or -1 for brand-new
        tokens (slot tags), which keep their random init.
        """
        export_dir = Path(export_dir)
        cfg = json.loads((export_dir / "config.json").read_text())
        sd = torch.load(export_dir / "decoder_joint.pt", map_location="cpu")

        src = index_map.clamp(min=0)
        has_src = (index_map >= 0)
        loaded = []
        with torch.no_grad():
            # embedding rows
            emb = sd["prediction.embed.weight"]
            self.prediction.embed.weight[has_src] = emb[src[has_src]].to(self.prediction.embed.weight)
            self.prediction.embed.weight[self.blank_id].zero_()
            loaded.append("prediction.embed.weight")

            # LSTM: shapes must match exactly
            lstm_sd = {k[len("prediction.lstm."):]: v for k, v in sd.items()
                       if k.startswith("prediction.lstm.")}
            missing, unexpected = self.prediction.lstm.load_state_dict(lstm_sd, strict=False)
            if missing or unexpected:
                warnings.warn(f"LSTM warm-start mismatch: missing={missing} unexpected={unexpected}")
            loaded += [f"prediction.lstm.{k}" for k in lstm_sd if k not in unexpected]

            # joint.pred (pred -> joint hidden)
            self.joint.pred.weight.copy_(sd["joint.pred.weight"])
            self.joint.pred.bias.copy_(sd["joint.pred.bias"])
            loaded += ["joint.pred.weight", "joint.pred.bias"]

            # joint.out rows (joint hidden -> vocab); pretrained may carry extra
            # TDT duration outputs after its blank -- they're simply ignored.
            W, bvec = sd["joint.out.weight"], sd["joint.out.bias"]
            self.joint.out.weight[has_src] = W[src[has_src]].to(self.joint.out.weight)
            self.joint.out.bias[has_src] = bvec[src[has_src]].to(self.joint.out.bias)
            loaded += ["joint.out.weight", "joint.out.bias"]

        self.pretrained_param_names = set(loaded)
        n_new = int((~has_src).sum())
        print(f"[rnnt] warm-started prediction net + joint from {export_dir} "
              f"({cfg.get('source_model')}); {n_new} new token rows randomly initialized, "
              f"joint.enc re-initialized for the HuBERT/WavLM features")

    @staticmethod
    def read_nemotron_config(export_dir):
        return json.loads((Path(export_dir) / "config.json").read_text())
