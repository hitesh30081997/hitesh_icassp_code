"""
vocab_nemotron.py
Target vocabulary that reuses the Nemotron ASR SentencePiece tokenizer and
appends atomic slot-tag tokens, so the pretrained RNN-T prediction network
and joint output layer can be warm-started row-for-row.

Id layout (blank last, like NeMo):
    [0 .. S-1]          Nemotron SentencePiece pieces   (pretrained rows)
    [S]                 <end_fill>                      (new)
    [S+1 .. S+K]        <fill_TYPE> for each slot type  (new)
    [S+K+1]             <blank>                         (pretrained blank row)

Same interface as vocab.CTCVocab / vocab_bpe.BPECTCVocab:
    encode, decode (CTC collapse), decode_tokens (RNN-T, no collapse),
    pad_id, blank_id, len(), save/load.
Requires: pip install sentencepiece
"""
import json
import shutil
from pathlib import Path

import torch
import sentencepiece as spm

from vocab import END_FILL_TOKEN


def _is_tag(word):
    return (word.startswith("<fill_") and word.endswith(">")) or word == END_FILL_TOKEN


class NemotronSlotVocab:
    TOKENIZER_FILE = "nemotron_tokenizer.model"
    META_FILE = "nemotron_vocab.json"

    def __init__(self, sp_model_path, slot_types):
        self.sp_model_path = str(sp_model_path)
        self.sp = spm.SentencePieceProcessor(model_file=self.sp_model_path)
        self.sp_size = self.sp.get_piece_size()
        self.slot_types = sorted(slot_types)
        self.tags = [END_FILL_TOKEN] + [f"<fill_{s}>" for s in self.slot_types]
        self.tag2id = {t: self.sp_size + i for i, t in enumerate(self.tags)}
        self.id2tag = {i: t for t, i in self.tag2id.items()}
        self.blank_id = self.sp_size + len(self.tags)
        self.pad_id = self.blank_id  # padded positions are masked via lengths

    def __len__(self):
        return self.blank_id + 1

    def encode(self, tagged_text: str):
        ids, buf = [], []

        def flush():
            if buf:
                ids.extend(self.sp.encode(" ".join(buf)))
                buf.clear()

        for word in tagged_text.strip().split():
            if _is_tag(word):
                flush()
                ids.append(self.tag2id.get(word, self.tag2id[END_FILL_TOKEN]))
            else:
                buf.append(word.lower())
        flush()
        return ids

    def decode_tokens(self, ids):
        """RNN-T output -> tagged text (no repeat-collapsing)."""
        words, buf = [], []

        def flush():
            if buf:
                text = self.sp.decode(buf).strip()
                if text:
                    words.append(text)
                buf.clear()

        for i in ids:
            if i == self.blank_id:
                continue
            if i in self.id2tag:
                flush()
                words.append(self.id2tag[i])
            elif 0 <= i < self.sp_size:
                buf.append(int(i))
        flush()
        return " ".join(" ".join(words).split())

    def decode(self, ids):
        """CTC greedy collapse then detokenize (lets this vocab work with the
        old CTC head too)."""
        collapsed, prev = [], None
        for i in ids:
            if i != prev and i != self.blank_id:
                collapsed.append(i)
            prev = i
        return self.decode_tokens(collapsed)

    def pretrained_index_map(self, pretrained_text_vocab_size):
        """For RNNTSlotHead.load_nemotron_pretrained: row in the pretrained
        embedding/joint.out for each of our ids (-1 = new token)."""
        if pretrained_text_vocab_size != self.sp_size:
            raise ValueError(
                f"tokenizer has {self.sp_size} pieces but pretrained decoder has "
                f"{pretrained_text_vocab_size}; export and vocab must come from the same model")
        m = torch.full((len(self),), -1, dtype=torch.long)
        m[: self.sp_size] = torch.arange(self.sp_size)
        m[self.blank_id] = pretrained_text_vocab_size  # pretrained blank
        return m

    def save(self, out_dir):
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        dst = out_dir / self.TOKENIZER_FILE
        if Path(self.sp_model_path).resolve() != dst.resolve():
            shutil.copy(self.sp_model_path, dst)
        (out_dir / self.META_FILE).write_text(json.dumps({"slot_types": self.slot_types}, indent=2))

    @classmethod
    def load(cls, out_dir):
        out_dir = Path(out_dir)
        meta = json.loads((out_dir / cls.META_FILE).read_text())
        return cls(out_dir / cls.TOKENIZER_FILE, meta["slot_types"])

    @classmethod
    def exists(cls, out_dir):
        out_dir = Path(out_dir)
        return (out_dir / cls.META_FILE).exists() and (out_dir / cls.TOKENIZER_FILE).exists()
