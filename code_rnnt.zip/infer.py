"""
infer.py
Run inference on a single audio file with a trained checkpoint.

Usage:
    python infer.py --ckpt ckpt/best_model.pt --ckpt_dir ckpt --wav path/to/utterance.wav

If ckpt_dir contains run_config.json (written by train.py), the model and
vocab are rebuilt from it (CTC or RNN-T, any vocab type) and the remaining
model flags below are ignored. Older checkpoints without it fall back to
the command-line flags (BiLSTM + CTC).
"""
import argparse
import json
from pathlib import Path

import torch
import torchaudio

from vocab import CTCVocab, extract_slots_from_tagged_text, strip_tags
from model import HubertSLUModel
from dataset import TARGET_SR


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--ckpt", required=True)
    p.add_argument("--ckpt_dir", required=True,
                   help="Dir with intent_labels.json, vocab files and run_config.json")
    p.add_argument("--wav", required=True)
    # legacy flags (only used when run_config.json is missing)
    p.add_argument("--hubert_name", default="facebook/hubert-base-ls960")
    p.add_argument("--semantic_layer", type=int, default=8)
    p.add_argument("--vocab_type", choices=["char", "bpe", "nemotron"], default="char")
    p.add_argument("--layer_fusion", choices=["single", "weighted_sum"], default="single")
    p.add_argument("--fusion_layers", type=str, default=None)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return p.parse_args()


def load_audio(path):
    waveform, sr = torchaudio.load(path)
    if waveform.shape[0] > 1:
        waveform = waveform.mean(dim=0, keepdim=True)
    if sr != TARGET_SR:
        waveform = torchaudio.functional.resample(waveform, sr, TARGET_SR)
    return waveform  # (1, T)


def load_vocab(vocab_type, ckpt_dir):
    if vocab_type == "bpe":
        from vocab_bpe import BPECTCVocab
        return BPECTCVocab.load(ckpt_dir / "bpe_tokenizer.json")
    if vocab_type == "nemotron":
        from vocab_nemotron import NemotronSlotVocab
        return NemotronSlotVocab.load(ckpt_dir)
    return CTCVocab.load(ckpt_dir / "ctc_vocab.json")


def main():
    args = parse_args()
    ckpt_dir = Path(args.ckpt_dir)
    intent_list = json.loads((ckpt_dir / "intent_labels.json").read_text())

    run_cfg_path = ckpt_dir / "run_config.json"
    if run_cfg_path.exists():
        run_cfg = json.loads(run_cfg_path.read_text())
        vocab = load_vocab(run_cfg["vocab_type"], ckpt_dir)
        model_kwargs = run_cfg["model_kwargs"]
    else:
        vocab = load_vocab(args.vocab_type, ckpt_dir)
        model_kwargs = dict(
            num_intents=len(intent_list),
            ctc_vocab_size=len(vocab),
            pad_id=vocab.pad_id,
            blank_id=vocab.blank_id,
            hubert_name=args.hubert_name,
            semantic_layer=args.semantic_layer,
            layer_fusion=args.layer_fusion,
            fusion_layers=([int(x) for x in args.fusion_layers.split(",")]
                           if args.fusion_layers else None),
        )

    model = HubertSLUModel(**model_kwargs)
    model.load_state_dict(torch.load(args.ckpt, map_location="cpu"))
    model.to(args.device).eval()

    waveform = load_audio(args.wav).to(args.device)
    attention_mask = torch.ones(waveform.shape, dtype=torch.long, device=args.device)

    with torch.no_grad():
        outputs = model(waveform, attention_mask)
        tagged_text = model.decode_slots(outputs, vocab)[0]

    intent = intent_list[outputs["intent_logits"].argmax(-1).item()]
    print("Intent    :", intent)
    print("Tagged    :", tagged_text)
    print("Transcript:", strip_tags(tagged_text))
    print("Slots     :", extract_slots_from_tagged_text(tagged_text))


if __name__ == "__main__":
    main()
