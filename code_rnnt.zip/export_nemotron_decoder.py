"""
export_nemotron_decoder.py
One-time export of the RNN-T prediction network, joint network and
SentencePiece tokenizer from an NVIDIA NeMo RNNT checkpoint (default:
nvidia/nemotron-speech-streaming-en-0.6b). After this, training/inference
only need `sentencepiece` -- NeMo is not required at train time.

Usage:
    pip install "nemo_toolkit[asr]"
    python export_nemotron_decoder.py \
        --model nvidia/nemotron-speech-streaming-en-0.6b \
        --out_dir ./nemotron_rnnt

Writes:
    out_dir/decoder_joint.pt   tensors: prediction.embed.*, prediction.lstm.*,
                               joint.pred.*, joint.enc.*, joint.out.*
    out_dir/config.json        dims + source info
    out_dir/tokenizer.model    SentencePiece model
"""
import argparse
import json
from pathlib import Path

import torch
import torch.nn as nn


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="nvidia/nemotron-speech-streaming-en-0.6b",
                   help="HF/NGC model name or path to a local .nemo file")
    p.add_argument("--out_dir", default="./nemotron_rnnt")
    args = p.parse_args()

    import nemo.collections.asr as nemo_asr
    if args.model.endswith(".nemo"):
        m = nemo_asr.models.ASRModel.restore_from(args.model, map_location="cpu")
    else:
        m = nemo_asr.models.ASRModel.from_pretrained(args.model, map_location="cpu")
    m.eval()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    # ---- prediction network ----
    pred = m.decoder.prediction
    embed = pred["embed"]
    dec_rnn = pred["dec_rnn"]
    lstm = dec_rnn.lstm if hasattr(dec_rnn, "lstm") else dec_rnn
    assert isinstance(lstm, nn.LSTM), f"unexpected prediction RNN type: {type(lstm)}"

    # ---- joint network ----
    joint = m.joint
    out_linear = [mod for mod in joint.joint_net if isinstance(mod, nn.Linear)][-1]
    act = next((type(mod).__name__.lower() for mod in joint.joint_net
                if not isinstance(mod, (nn.Linear, nn.Dropout))), "relu")

    sd = {"prediction.embed.weight": embed.weight.detach().cpu()}
    for k, v in lstm.state_dict().items():
        sd[f"prediction.lstm.{k}"] = v.detach().cpu()
    for name, lin in (("pred", joint.pred), ("enc", joint.enc), ("out", out_linear)):
        sd[f"joint.{name}.weight"] = lin.weight.detach().cpu()
        sd[f"joint.{name}.bias"] = lin.bias.detach().cpu()
    torch.save(sd, out / "decoder_joint.pt")

    tok = m.tokenizer
    sp = getattr(tok, "tokenizer", None)
    if sp is None or not hasattr(sp, "serialized_model_proto"):
        raise RuntimeError("Expected a SentencePiece tokenizer on this model")
    (out / "tokenizer.model").write_bytes(sp.serialized_model_proto())

    text_vocab = tok.vocab_size
    cfg = {
        "source_model": args.model,
        "text_vocab_size": text_vocab,             # pretrained blank id == this
        "embed_rows": embed.weight.shape[0],
        "pred_embed_dim": embed.weight.shape[1],
        "pred_hidden": lstm.hidden_size,
        "pred_layers": lstm.num_layers,
        "pred_proj": getattr(lstm, "proj_size", 0),
        "joint_hidden": joint.pred.weight.shape[0],
        "joint_activation": act,
        "joint_out_rows": out_linear.weight.shape[0],  # text_vocab + 1 (+ TDT durations)
        "orig_encoder_dim": joint.enc.weight.shape[1],
    }
    (out / "config.json").write_text(json.dumps(cfg, indent=2))
    print(json.dumps(cfg, indent=2))
    print(f"[export] wrote {out}/decoder_joint.pt, config.json, tokenizer.model")


if __name__ == "__main__":
    main()
