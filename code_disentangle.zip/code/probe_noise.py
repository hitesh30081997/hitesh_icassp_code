"""
probe_noise.py
Measures how much noise information is left in the CONTENT embedding.

Extracts the utterance content embedding (intent pooled + slot mean) for the
dev set in clean and 5 dB versions, then trains a logistic-regression probe
(5-fold CV) to predict clean vs noisy.

  ~50% accuracy  -> content embedding is noise-invariant (good)
  ~100% accuracy -> noise is still fully encoded

Also reports the probe on z_noise, which SHOULD be near 100%.
Run it on your old clean checkpoint too as a baseline: its weights load into
DisentangledSLUModel with identity adapters, so the content number is valid
(ignore the z_noise number there, that branch is untrained).

    python probe_noise.py --ckpt ckpt_dis/best_model.pt --ckpt_dir ckpt_dis \
        --slurp_jsonl_dir /path/slurp/dataset/slurp \
        --clean_audio_root /path/slurp/audio --noisy_audio_root /path/slurp_5db/audio \
        --hubert_name microsoft/wavlm-base-plus --layer_fusion weighted_sum
"""
import argparse
import functools
from pathlib import Path

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, Subset

from dataset import SlurpDataset, collate_fn
from model_disentangle import DisentangledSLUModel
from train import build_or_load_vocabs


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ckpt", required=True)
    p.add_argument("--ckpt_dir", required=True)
    p.add_argument("--slurp_jsonl_dir", required=True)
    p.add_argument("--clean_audio_root", required=True)
    p.add_argument("--noisy_audio_root", required=True)
    p.add_argument("--hubert_name", default="facebook/hubert-base-ls960")
    p.add_argument("--semantic_layer", type=int, default=8)
    p.add_argument("--vocab_type", choices=["char", "bpe"], default="char")
    p.add_argument("--bpe_vocab_size", type=int, default=500)
    p.add_argument("--layer_fusion", choices=["single", "weighted_sum"], default="single")
    p.add_argument("--fusion_layers", type=str, default=None)
    p.add_argument("--noise_layers", type=str, default="1,2,3,4")
    p.add_argument("--max_utts", type=int, default=2000)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = p.parse_args()

    intent_list, intent2id, ctc_vocab = build_or_load_vocabs(args, Path(args.ckpt_dir))
    model = DisentangledSLUModel(
        num_intents=len(intent_list), ctc_vocab_size=len(ctc_vocab),
        pad_id=ctc_vocab.pad_id, blank_id=ctc_vocab.blank_id,
        hubert_name=args.hubert_name, semantic_layer=args.semantic_layer,
        layer_fusion=args.layer_fusion,
        fusion_layers=([int(x) for x in args.fusion_layers.split(",")]
                       if args.fusion_layers else None),
        noise_layers=[int(x) for x in args.noise_layers.split(",")],
    )
    missing, _ = model.load_state_dict(torch.load(args.ckpt, map_location="cpu"), strict=False)
    if missing:
        print(f"[probe] params not in ckpt (random/identity): {sorted({k.split('.')[0] for k in missing})}")
    model.to(args.device).eval()

    collate = functools.partial(collate_fn, pad_id=ctc_vocab.pad_id)
    jsonl = Path(args.slurp_jsonl_dir) / "devel.jsonl"
    feats = {"content": [], "noise": []}
    labels = []
    for label, root in ((0, args.clean_audio_root), (1, args.noisy_audio_root)):
        ds = SlurpDataset(jsonl, root, ctc_vocab, intent2id)
        ds = Subset(ds, range(min(args.max_utts, len(ds))))
        for batch in DataLoader(ds, batch_size=8, collate_fn=collate):
            with torch.no_grad():
                out = model(batch["input_values"].to(args.device),
                            batch["attention_mask"].to(args.device), return_aux=True)
            feats["content"].append(out["content_utt"].cpu().numpy())
            feats["noise"].append(out["z_noise"].cpu().numpy())
            labels += [label] * batch["input_values"].shape[0]

    y = np.array(labels)
    for name in ("content", "noise"):
        X = np.concatenate(feats[name])
        clf = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000))
        acc = cross_val_score(clf, X, y, cv=5).mean()
        print(f"[probe] clean-vs-noisy accuracy from {name:7s} embedding: {acc:.3f}")


if __name__ == "__main__":
    main()
