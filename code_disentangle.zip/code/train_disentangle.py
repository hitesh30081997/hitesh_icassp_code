"""
train_disentangle.py
Noise-disentanglement training on paired clean / 5 dB SLURP.

Recommended: start from your best clean checkpoint (train.py) and reuse its
vocab so label ids match.

    python train_disentangle.py \
        --slurp_jsonl_dir /path/slurp/dataset/slurp \
        --clean_audio_root /path/slurp/audio \
        --noisy_audio_root /path/slurp_5db/audio \
        --output_dir ./ckpt_dis \
        --vocab_from ./ckpt_clean \
        --init_ckpt ./ckpt_clean/best_model.pt \
        --teacher_ckpt ./ckpt_clean/best_model.pt \
        --hubert_name microsoft/wavlm-base-plus \
        --layer_fusion weighted_sum \
        --epochs 15 --batch_size 4 --lr 2e-5

--batch_size is the number of PAIRS (the encoder sees 2x that).
The model config flags (hubert_name, layer_fusion, fusion_layers,
semantic_layer, vocab_type) must match the checkpoints you load.
"""
import argparse
import functools
import json
import math
import shutil
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset import SlurpDataset, collate_fn
from dataset_paired import PairedSlurpDataset, paired_collate_fn
from model import HubertSLUModel
from model_disentangle import DisentangledSLUModel
from train import build_or_load_vocabs, evaluate


def parse_args():
    p = argparse.ArgumentParser()
    # data
    p.add_argument("--slurp_jsonl_dir", required=True)
    p.add_argument("--clean_audio_root", required=True)
    p.add_argument("--noisy_audio_root", required=True)
    p.add_argument("--output_dir", default="./ckpt_dis")
    p.add_argument("--vocab_from", default=None,
                   help="Checkpoint dir of an earlier run; its intent_labels.json and "
                        "ctc_vocab.json / bpe_tokenizer.json are copied so ids match.")
    # model (same meaning as train.py)
    p.add_argument("--hubert_name", default="facebook/hubert-base-ls960")
    p.add_argument("--semantic_layer", type=int, default=8)
    p.add_argument("--vocab_type", choices=["char", "bpe"], default="char")
    p.add_argument("--bpe_vocab_size", type=int, default=500)
    p.add_argument("--layer_fusion", choices=["single", "weighted_sum"], default="single")
    p.add_argument("--fusion_layers", type=str, default=None)
    p.add_argument("--freeze_feature_extractor", action="store_true", default=True)
    p.add_argument("--freeze_encoder_layers", type=int, default=0)
    p.add_argument("--noise_layers", type=str, default="1,2,3,4",
                   help="Low encoder layers feeding the noise branch.")
    # init / teacher
    p.add_argument("--init_ckpt", default=None, help="Clean checkpoint to warm-start from.")
    p.add_argument("--teacher_ckpt", default=None,
                   help="Frozen clean model used as KD target (fed clean audio).")
    # optimisation
    p.add_argument("--epochs", type=int, default=15)
    p.add_argument("--batch_size", type=int, default=4, help="pairs per batch")
    p.add_argument("--lr", type=float, default=2e-5)
    p.add_argument("--head_lr_mult", type=float, default=20.0)
    p.add_argument("--grad_clip", type=float, default=5.0)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--max_audio_seconds", type=float, default=15.0)
    p.add_argument("--log_every", type=int, default=50)
    p.add_argument("--select_on", choices=["noisy", "clean", "mean"], default="mean")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    # loss weights
    p.add_argument("--ctc_loss_weight", type=float, default=1.0)
    p.add_argument("--w_cons", type=float, default=1.0, help="frame content consistency")
    p.add_argument("--w_kd_intent", type=float, default=1.0)
    p.add_argument("--w_kd_ctc", type=float, default=0.5)
    p.add_argument("--kd_temp", type=float, default=2.0)
    p.add_argument("--w_contrast", type=float, default=0.1)
    p.add_argument("--contrast_temp", type=float, default=0.1)
    p.add_argument("--w_adv", type=float, default=1.0, help="discriminator CE weight")
    p.add_argument("--grl_max", type=float, default=0.1,
                   help="Max gradient-reversal strength reaching the encoder.")
    p.add_argument("--w_noise", type=float, default=0.5)
    p.add_argument("--w_orth", type=float, default=0.1)
    return p.parse_args()


def grl_schedule(progress, max_lambda):
    """DANN schedule: 0 -> max_lambda smoothly, so the adversary cannot
    wreck the representation before the task heads are stable."""
    return max_lambda * (2.0 / (1.0 + math.exp(-10.0 * progress)) - 1.0)


def main():
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.vocab_from:
        for name in ("intent_labels.json", "ctc_vocab.json", "bpe_tokenizer.json"):
            src = Path(args.vocab_from) / name
            if src.exists():
                shutil.copy(src, out_dir / name)

    intent_list, intent2id, ctc_vocab = build_or_load_vocabs(args, out_dir)
    print(f"[vocab] {len(intent_list)} intents, {len(ctc_vocab)} CTC symbols")

    jdir = Path(args.slurp_jsonl_dir)
    train_ds = PairedSlurpDataset(jdir / "train.jsonl", args.clean_audio_root,
                                  args.noisy_audio_root, ctc_vocab, intent2id,
                                  args.max_audio_seconds)
    dev_clean = SlurpDataset(jdir / "devel.jsonl", args.clean_audio_root,
                             ctc_vocab, intent2id, args.max_audio_seconds)
    dev_noisy = SlurpDataset(jdir / "devel.jsonl", args.noisy_audio_root,
                             ctc_vocab, intent2id, args.max_audio_seconds)
    print(f"[data] train pairs={len(train_ds)} dev={len(dev_clean)}")

    pcollate = functools.partial(paired_collate_fn, pad_id=ctc_vocab.pad_id)
    collate = functools.partial(collate_fn, pad_id=ctc_vocab.pad_id)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.num_workers, collate_fn=pcollate,
                              drop_last=True)
    dev_loaders = {
        name: DataLoader(ds, batch_size=args.batch_size * 2, shuffle=False,
                         num_workers=args.num_workers, collate_fn=collate)
        for name, ds in (("clean", dev_clean), ("noisy", dev_noisy))
    }

    model_kwargs = dict(
        num_intents=len(intent_list),
        ctc_vocab_size=len(ctc_vocab),
        pad_id=ctc_vocab.pad_id,
        blank_id=ctc_vocab.blank_id,
        hubert_name=args.hubert_name,
        semantic_layer=args.semantic_layer,
        layer_fusion=args.layer_fusion,
        fusion_layers=([int(x) for x in args.fusion_layers.split(",")]
                       if args.fusion_layers else None),
        freeze_feature_extractor=args.freeze_feature_extractor,
        freeze_encoder_layers=args.freeze_encoder_layers,
    )
    model = DisentangledSLUModel(
        **model_kwargs,
        noise_layers=[int(x) for x in args.noise_layers.split(",")],
        num_noise_classes=2,
    )
    if args.init_ckpt:
        sd = torch.load(args.init_ckpt, map_location="cpu")
        missing, unexpected = model.load_state_dict(sd, strict=False)
        print(f"[init] loaded {args.init_ckpt}; new (randomly initialised) params: "
              f"{sorted({k.split('.')[0] for k in missing})}")
        if unexpected:
            print(f"[init] WARNING unexpected keys: {unexpected[:5]} ...")
    model.to(args.device)

    teacher = None
    if args.teacher_ckpt:
        teacher = HubertSLUModel(**model_kwargs)
        teacher.load_state_dict(torch.load(args.teacher_ckpt, map_location="cpu"))
        teacher.to(args.device).eval()
        for p in teacher.parameters():
            p.requires_grad = False
        print(f"[teacher] frozen clean teacher from {args.teacher_ckpt}")

    encoder_params = [p for p in model.hubert.parameters() if p.requires_grad]
    encoder_ids = {id(p) for p in encoder_params}
    head_params = [p for p in model.parameters() if p.requires_grad and id(p) not in encoder_ids]
    head_lr = args.lr * args.head_lr_mult
    optimizer = torch.optim.AdamW([
        {"params": encoder_params, "lr": args.lr},
        {"params": head_params, "lr": head_lr},
    ])
    total_steps = max(1, args.epochs * len(train_loader))
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer, max_lr=[args.lr, head_lr], total_steps=total_steps)

    weights = {
        "ctc": args.ctc_loss_weight, "cons": args.w_cons,
        "kd_intent": args.w_kd_intent, "kd_ctc": args.w_kd_ctc, "kd_temp": args.kd_temp,
        "contrast": args.w_contrast, "contrast_temp": args.contrast_temp,
        "adv": args.w_adv, "noise": args.w_noise, "orth": args.w_orth,
    }

    def score(m):
        if args.select_on == "mean":
            return 0.5 * (m["clean"]["f1"] + m["noisy"]["f1"])
        return m[args.select_on]["f1"]

    best, step, history = -1.0, 0, []
    for epoch in range(args.epochs):
        model.train()
        pbar = tqdm(train_loader, desc=f"epoch {epoch}")
        for batch in pbar:
            if batch is None:
                continue
            batch = {k: (v.to(args.device) if torch.is_tensor(v) else v) for k, v in batch.items()}
            model.grl_lambda = grl_schedule(step / total_steps, args.grl_max)

            out = model(batch["input_values"], batch["attention_mask"], return_aux=True)
            t_out = None
            if teacher is not None:
                B = batch["pair_size"]
                with torch.no_grad():
                    t_out = teacher(batch["input_values"][:B], batch["attention_mask"][:B])

            loss, logs = model.compute_disentangle_loss(batch, out, weights, teacher_out=t_out)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            optimizer.step()
            scheduler.step()

            step += 1
            if step % args.log_every == 0:
                pbar.set_postfix(loss=float(loss.detach()), grl=round(model.grl_lambda, 3),
                                 **{k: round(v, 3) for k, v in logs.items()})

        metrics = {name: evaluate(model, dl, args.device, ctc_vocab, intent_list)
                   for name, dl in dev_loaders.items()}
        for name, m in metrics.items():
            print(f"[epoch {epoch}] dev-{name}: intent_acc={m['intent_accuracy']:.4f} "
                  f"slu_f1={m['f1']:.4f}")
        history.append({"epoch": epoch, **metrics})

        s = score(metrics)
        if s > best:
            best = s
            torch.save(model.state_dict(), out_dir / "best_model.pt")
            print(f"[epoch {epoch}] new best ({args.select_on} slu_f1={best:.4f})")

    torch.save(model.state_dict(), out_dir / "last_model.pt")
    (out_dir / "history.json").write_text(json.dumps(history, indent=2))

    # final test on clean and 5 dB with the best checkpoint
    test_jsonl = jdir / "test.jsonl"
    if test_jsonl.exists():
        model.load_state_dict(torch.load(out_dir / "best_model.pt", map_location=args.device))
        results = {}
        for name, root in (("clean", args.clean_audio_root), ("noisy", args.noisy_audio_root)):
            ds = SlurpDataset(test_jsonl, root, ctc_vocab, intent2id, args.max_audio_seconds)
            dl = DataLoader(ds, batch_size=args.batch_size * 2, shuffle=False,
                            num_workers=args.num_workers, collate_fn=collate)
            results[name] = evaluate(model, dl, args.device, ctc_vocab, intent_list)
            print(f"[test-{name}] intent_acc={results[name]['intent_accuracy']:.4f} "
                  f"slu_f1={results[name]['f1']:.4f}")
        (out_dir / "test_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
