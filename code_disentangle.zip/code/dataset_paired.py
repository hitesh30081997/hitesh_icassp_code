"""
dataset_paired.py
Paired clean / noisy SLURP dataset for noise-disentanglement training.

Assumes the noisy (e.g. 5 dB SNR) copy of SLURP has the SAME structure and
file names as the clean one:

    clean_root/slurp_real/<file>.flac     noisy_root/slurp_real/<file>.flac
    clean_root/slurp_synth/<file>.flac    noisy_root/slurp_synth/<file>.flac

Each item returns BOTH versions of the same recording, cropped to the same
length so their encoder frames line up 1:1 (needed for frame-level
consistency / distillation losses).

The collate function stacks them as ONE batch of size 2B:
    rows [0, B)   -> clean
    rows [B, 2B)  -> noisy (same order)
so a single encoder forward pass serves both, and the loss can split them
with batch["pair_size"].
"""
from pathlib import Path

import torch
import torchaudio

from dataset import SlurpDataset, TARGET_SR


class PairedSlurpDataset(SlurpDataset):
    def __init__(self, jsonl_path, clean_audio_root, noisy_audio_root,
                 ctc_vocab, intent2id, max_audio_seconds=15.0,
                 noise_label=1, drop_missing=True):
        super().__init__(jsonl_path, clean_audio_root, ctc_vocab, intent2id,
                         max_audio_seconds)
        self.noisy_root = Path(noisy_audio_root)
        self.noise_label = noise_label

        if drop_missing:
            # Keep only recordings that exist in BOTH trees.
            before = len(self.examples)
            self.examples = [
                ex for ex in self.examples
                if self._locate(self.audio_root, ex["audio_file"]) is not None
                and self._locate(self.noisy_root, ex["audio_file"]) is not None
            ]
            dropped = before - len(self.examples)
            if dropped:
                print(f"[paired] dropped {dropped} recordings missing a clean or noisy copy")

    @staticmethod
    def _locate(root, fname):
        for sub in ("slurp_real", "slurp_synth"):
            cand = root / sub / fname
            if cand.exists():
                return cand
        cand = root / fname
        return cand if cand.exists() else None

    @staticmethod
    def _load(path):
        wav, sr = torchaudio.load(str(path))
        if wav.shape[0] > 1:
            wav = wav.mean(dim=0, keepdim=True)
        if sr != TARGET_SR:
            wav = torchaudio.functional.resample(wav, sr, TARGET_SR)
        return wav.squeeze(0)

    def __getitem__(self, idx):
        ex = self.examples[idx]
        clean_path = self._locate(self.audio_root, ex["audio_file"])
        noisy_path = self._locate(self.noisy_root, ex["audio_file"])
        if clean_path is None or noisy_path is None:
            raise FileNotFoundError(f"Missing clean/noisy copy of {ex['audio_file']}")

        clean = self._load(clean_path)
        noisy = self._load(noisy_path)
        # Same length -> same number of encoder frames -> frame-aligned pairs.
        L = min(clean.numel(), noisy.numel(), self.max_samples)
        clean, noisy = clean[:L], noisy[:L]

        return {
            "clean_values": clean,
            "noisy_values": noisy,
            "intent_id": ex["intent_id"],
            "ctc_ids": torch.tensor(ex["ctc_ids"], dtype=torch.long),
            "tagged_text": ex["tagged_text"],
            "noise_label": self.noise_label,
        }


def paired_collate_fn(batch, pad_id):
    B = len(batch)
    lens = [b["clean_values"].shape[0] for b in batch]
    max_len = max(lens)

    input_values = torch.zeros(2 * B, max_len)
    attention_mask = torch.zeros(2 * B, max_len, dtype=torch.long)
    for i, b in enumerate(batch):
        L = lens[i]
        input_values[i, :L] = b["clean_values"]
        input_values[B + i, :L] = b["noisy_values"]
        attention_mask[i, :L] = 1
        attention_mask[B + i, :L] = 1

    ctc_lens = [b["ctc_ids"].shape[0] for b in batch]
    max_ctc = max(ctc_lens)
    ctc_targets = torch.full((B, max_ctc), pad_id, dtype=torch.long)
    for i, b in enumerate(batch):
        ctc_targets[i, :ctc_lens[i]] = b["ctc_ids"]

    intent_ids = torch.tensor([b["intent_id"] for b in batch], dtype=torch.long)
    noise_labels = torch.tensor([0] * B + [b["noise_label"] for b in batch],
                                dtype=torch.long)
    texts = [b["tagged_text"] for b in batch]

    return {
        "input_values": input_values,
        "attention_mask": attention_mask,
        "intent_ids": intent_ids.repeat(2),
        "ctc_targets": ctc_targets.repeat(2, 1),
        "ctc_target_lens": torch.tensor(ctc_lens, dtype=torch.long).repeat(2),
        "noise_labels": noise_labels,
        "tagged_texts": texts + texts,
        "pair_size": B,
    }
