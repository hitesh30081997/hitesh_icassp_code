"""
model_disentangle.py
Noise-disentangled version of HubertSLUModel.

Extends model.HubertSLUModel (same encoder, layer fusion, intent head,
BiLSTM+CTC slot head) with:

  CONTENT path (what the intent/slot heads see)
    - A residual "content adapter" per branch, zero-initialised so it starts
      as an identity -> a clean checkpoint from train.py loads and behaves
      exactly like before at step 0.
    - Trained to be noise-INVARIANT with:
        * frame-level cosine consistency   noisy content  -> clean content
        * intent KD (KL)                    noisy logits   -> clean/teacher logits
        * CTC-posterior KD (frame KL)       noisy CTC      -> clean/teacher CTC
        * paired InfoNCE                    noisy utt emb <-> clean utt emb
        * adversarial noise discriminator behind a gradient-reversal layer

  NOISE path (where noise information is pushed instead)
    - A learned weighted sum over LOW encoder layers (acoustic, noise-rich)
      -> projection -> attention pool -> z_noise, trained to predict the
      noise condition.
    - Cross-covariance (decorrelation) penalty between content and z_noise.

Only the content path is used for predictions, so inference cost is the
same as the original model (the noise branch is skipped unless
return_aux=True).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from model import HubertSLUModel, AttentionPool, LayerWeightedSum


# ---------------------------------------------------------------- helpers
class _GradReverse(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lambd):
        ctx.lambd = lambd
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return -ctx.lambd * grad_output, None


def grad_reverse(x, lambd):
    return _GradReverse.apply(x, lambd)


def masked_mean(x, mask):
    m = mask.unsqueeze(-1).to(x.dtype)
    return (x * m).sum(1) / m.sum(1).clamp(min=1.0)


def frame_cosine_loss(student, target, mask):
    """1 - cos per frame, averaged over valid frames. Target is detached."""
    cos = F.cosine_similarity(student, target.detach(), dim=-1)  # (B, T)
    return ((1.0 - cos) * mask).sum() / mask.sum().clamp(min=1.0)


def kd_kl(student_logits, teacher_logits, temp):
    return F.kl_div(
        F.log_softmax(student_logits / temp, dim=-1),
        F.softmax(teacher_logits.detach() / temp, dim=-1),
        reduction="batchmean",
    ) * (temp ** 2)


def cross_cov_penalty(a, b, eps=1e-5):
    """Mean squared cross-correlation between two sets of features.
    0 when every content dim is linearly uncorrelated with every noise dim."""
    a = (a - a.mean(0)) / (a.std(0) + eps)
    b = (b - b.mean(0)) / (b.std(0) + eps)
    c = a.t() @ b / max(1, a.shape[0] - 1)
    return c.pow(2).mean()


class ContentAdapter(nn.Module):
    """Residual bottleneck adapter, zero-initialised output -> identity at init."""

    def __init__(self, hidden, bottleneck=256, dropout=0.1):
        super().__init__()
        self.norm = nn.LayerNorm(hidden)
        self.down = nn.Linear(hidden, bottleneck)
        self.up = nn.Linear(bottleneck, hidden)
        self.drop = nn.Dropout(dropout)
        nn.init.zeros_(self.up.weight)
        nn.init.zeros_(self.up.bias)

    def forward(self, x):
        return x + self.up(self.drop(F.gelu(self.down(self.norm(x)))))


# ------------------------------------------------------------------ model
class DisentangledSLUModel(HubertSLUModel):
    def __init__(self, *args, noise_layers=None, num_noise_classes=2,
                 noise_dim=128, adapter_bottleneck=256, **kwargs):
        super().__init__(*args, **kwargs)
        H = self.hubert.config.hidden_size
        dropout = kwargs.get("dropout", 0.1)

        # content path
        self.content_adapter_intent = ContentAdapter(H, adapter_bottleneck, dropout)
        self.content_adapter_slot = ContentAdapter(H, adapter_bottleneck, dropout)

        # noise path (low layers carry most channel / noise information)
        self.noise_layers = noise_layers or [1, 2, 3, 4]
        self.noise_layer_fusion = LayerWeightedSum(len(self.noise_layers))
        self.noise_proj = nn.Sequential(nn.LayerNorm(H), nn.Linear(H, noise_dim), nn.GELU())
        self.noise_pool = AttentionPool(noise_dim)
        self.noise_head = nn.Linear(noise_dim, num_noise_classes)

        # adversary on the content embedding (intent pooled + slot mean = 2H)
        self.noise_disc = nn.Sequential(
            nn.Linear(2 * H, 256), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(256, num_noise_classes),
        )
        self.grl_lambda = 0.0  # scheduled from the training loop

    def forward(self, input_values, attention_mask, ctc_target_lens=None,
                return_aux=False):
        outputs = self.hubert(
            input_values=input_values,
            attention_mask=attention_mask,
            output_hidden_states=True,
        )
        hs = outputs.hidden_states

        if self.layer_fusion == "weighted_sum":
            selected = [hs[i] for i in self.fusion_layers]
            intent_feats = self.intent_layer_fusion(selected)
            slot_feats_in = self.slot_layer_fusion(selected)
        else:
            intent_feats = slot_feats_in = hs[self.semantic_layer]

        if self._normalize_feats:
            intent_feats = self.feat_norm(intent_feats)
            slot_feats_in = self.feat_norm(slot_feats_in)

        frame_mask, feat_lens = self._feature_mask_from_attention_mask(attention_mask)
        T = intent_feats.shape[1]
        frame_mask = frame_mask[:, :T]
        feat_lens = feat_lens.clamp(max=T)

        # ---- content path ----
        intent_content = self.content_adapter_intent(intent_feats)
        slot_content = self.content_adapter_slot(slot_feats_in)

        pooled = self.intent_pool(intent_content, frame_mask)
        intent_logits = self.intent_head(self.intent_dropout(pooled))

        slot_feats, _ = self.slot_lstm(slot_content)
        slot_feats = self.slot_dropout(slot_feats)
        ctc_logits = self.ctc_head(slot_feats)
        log_probs = torch.log_softmax(ctc_logits, dim=-1).transpose(0, 1)

        out = {
            "intent_logits": intent_logits,
            "ctc_log_probs": log_probs,
            "feat_lens": feat_lens,
        }
        if not return_aux:
            return out

        # ---- noise path + adversary (training only) ----
        noise_in = self.noise_layer_fusion([hs[i] for i in self.noise_layers])
        noise_feats = self.noise_proj(noise_in[:, :T])
        z_noise = self.noise_pool(noise_feats, frame_mask)

        content_utt = torch.cat([pooled, masked_mean(slot_content, frame_mask)], dim=-1)

        out.update({
            "frame_mask": frame_mask,
            "intent_content": intent_content,
            "slot_content": slot_content,
            "content_utt": content_utt,
            "z_noise": z_noise,
            "noise_logits": self.noise_head(z_noise),
            "disc_logits": self.noise_disc(grad_reverse(content_utt, self.grl_lambda)),
        })
        return out

    # ------------------------------------------------------------- losses
    def compute_disentangle_loss(self, batch, out, w, teacher_out=None):
        """
        batch: from dataset_paired.paired_collate_fn (rows [0,B)=clean, [B,2B)=noisy)
        out:   forward(..., return_aux=True) on the full 2B batch
        w:     dict of loss weights (see train_disentangle.py)
        teacher_out: optional frozen clean-teacher outputs on the CLEAN half only
        """
        B = batch["pair_size"]
        c, n = slice(0, B), slice(B, 2 * B)
        logs = {}

        # 1) task loss on clean + noisy
        total, intent_loss, ctc_loss = self.compute_loss(batch, out, ctc_loss_weight=w["ctc"])
        logs["intent"], logs["ctc"] = float(intent_loss), float(ctc_loss)

        mask = (out["frame_mask"][c] * out["frame_mask"][n]).float()  # (B, T)

        # 2) frame-level content consistency (noisy -> clean, clean detached)
        if w["cons"] > 0:
            l = frame_cosine_loss(out["intent_content"][n], out["intent_content"][c], mask) \
                + frame_cosine_loss(out["slot_content"][n], out["slot_content"][c], mask)
            total = total + w["cons"] * l
            logs["cons"] = float(l)

        # 3) intent KD: noisy student matches clean (teacher or self) posteriors
        if w["kd_intent"] > 0:
            tgt = teacher_out["intent_logits"] if teacher_out is not None else out["intent_logits"][c]
            l = kd_kl(out["intent_logits"][n], tgt, w["kd_temp"])
            total = total + w["kd_intent"] * l
            logs["kd_int"] = float(l)

        # 4) CTC-posterior KD, frame by frame (helps transcript + slot tags)
        if w["kd_ctc"] > 0:
            s_lp = out["ctc_log_probs"][:, n]                          # (T, B, V)
            t_lp = (teacher_out["ctc_log_probs"] if teacher_out is not None
                    else out["ctc_log_probs"][:, c]).detach()
            Tm = min(s_lp.shape[0], t_lp.shape[0], mask.shape[1])
            kl = (t_lp[:Tm].exp() * (t_lp[:Tm] - s_lp[:Tm])).sum(-1).transpose(0, 1)  # (B, Tm)
            m = mask[:, :Tm]
            l = (kl * m).sum() / m.sum().clamp(min=1.0)
            total = total + w["kd_ctc"] * l
            logs["kd_ctc"] = float(l)

        # 5) paired InfoNCE on utterance content embeddings
        if w["contrast"] > 0 and B > 1:
            zc = F.normalize(out["content_utt"][c], dim=-1)
            zn = F.normalize(out["content_utt"][n], dim=-1)
            logits = zn @ zc.t() / w["contrast_temp"]
            texts = batch["tagged_texts"][:B]
            # same sentence read by another speaker is not a true negative
            same = torch.tensor(
                [[(texts[i] == texts[j]) and i != j for j in range(B)] for i in range(B)],
                device=logits.device,
            )
            logits = logits.masked_fill(same, float("-inf"))
            labels = torch.arange(B, device=logits.device)
            l = 0.5 * (F.cross_entropy(logits, labels) + F.cross_entropy(logits.t(), labels))
            total = total + w["contrast"] * l
            logs["nce"] = float(l)

        labels = batch["noise_labels"]

        # 6) adversarial: discriminator learns noise, GRL makes content hide it
        if w["adv"] > 0:
            l = F.cross_entropy(out["disc_logits"], labels)
            total = total + w["adv"] * l
            logs["adv"] = float(l)
            logs["disc_acc"] = float((out["disc_logits"].argmax(-1) == labels).float().mean())

        # 7) noise branch must encode the noise condition
        if w["noise"] > 0:
            l = F.cross_entropy(out["noise_logits"], labels)
            total = total + w["noise"] * l
            logs["noise"] = float(l)

        # 8) content and noise embeddings decorrelated
        if w["orth"] > 0:
            l = cross_cov_penalty(out["content_utt"], out["z_noise"])
            total = total + w["orth"] * l
            logs["orth"] = float(l)

        return total, logs
