"""
denoise.py
Noise disentanglement at the CNN feature-encoder output of WavLM/HuBERT.

Idea
----
    noisy wav --> [student CNN (trainable)] --> z_noisy --> feature_projection --> Transformer --> SLU heads
    clean wav --> [teacher CNN (frozen)]    --> z_clean   (target only)

    L_recon = masked distance(z_noisy, z_clean)

The teacher is the CNN feature encoder of the SAME pretrained checkpoint,
loaded fresh from `from_pretrained` and fully frozen, so the target space
never drifts while the student CNN learns to map noisy speech onto the
representation it would have produced for the clean recording. Both
tensors are taken *before* `feature_projection` (i.e. before its
LayerNorm + Linear 512->768), shape (B, T, C) with C = conv_dim[-1] (512
for WavLM/HuBERT base & large).

The teacher is deliberately NOT a submodule of HubertSLUModel: it is not
saved in checkpoints and is not needed at inference (infer.py unchanged).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModel


class FrozenCleanCNN(nn.Module):
    """CNN feature encoder of a pretrained SSL checkpoint, frozen, eval-only."""

    def __init__(self, backbone_name: str):
        super().__init__()
        full = AutoModel.from_pretrained(backbone_name)
        self.cnn = full.feature_extractor
        del full  # drop Transformer / projection; only the CNN is kept
        self.cnn._freeze_parameters()
        for p in self.cnn.parameters():
            p.requires_grad = False
        self.eval()

    def train(self, mode: bool = True):
        # Always stay in eval mode, even if someone calls .train() on it.
        return super().train(False)

    @torch.no_grad()
    def forward(self, clean_values):
        # clean_values: (B, S) raw waveform -> (B, T, C)
        return self.cnn(clean_values).transpose(1, 2)


def cnn_reconstruction_loss(student, teacher, frame_mask,
                            loss_type: str = "l1", feat_norm: str = "none"):
    """Masked frame-level distance between student (noisy) and teacher
    (clean) CNN features.

    student, teacher: (B, T, C); frame_mask: (B, T) with 1 = valid frame.
    loss_type: "l1" | "mse" | "cosine" | "l1_cosine"
    feat_norm: "none"      -> compare raw CNN outputs
               "layernorm" -> parameter-free per-frame LayerNorm on both
                              first (scale-invariant; mirrors the LayerNorm
                              that feature_projection applies next)
    """
    T = min(student.size(1), teacher.size(1), frame_mask.size(1))
    s = student[:, :T].float()
    t = teacher[:, :T].float().detach()
    m = frame_mask[:, :T].float()

    if feat_norm == "layernorm":
        s = F.layer_norm(s, s.shape[-1:])
        t = F.layer_norm(t, t.shape[-1:])
    elif feat_norm != "none":
        raise ValueError(f"unknown feat_norm: {feat_norm}")

    if loss_type == "l1":
        per_frame = (s - t).abs().mean(-1)
    elif loss_type == "mse":
        per_frame = (s - t).pow(2).mean(-1)
    elif loss_type == "cosine":
        per_frame = 1.0 - F.cosine_similarity(s, t, dim=-1)
    elif loss_type == "l1_cosine":
        per_frame = (s - t).abs().mean(-1) + (1.0 - F.cosine_similarity(s, t, dim=-1))
    else:
        raise ValueError(f"unknown loss_type: {loss_type}")

    return (per_frame * m).sum() / m.sum().clamp(min=1.0)
