"""
check_audio.py
Find audio files that are missing or cannot be decoded, for every SLURP
split and every audio root (clean and noisy), so they can be regenerated.

Usage:
    python check_audio.py \
        --slurp_jsonl_dir /path/slurp/dataset/slurp \
        --audio_roots /path/slurp/audio /path/slurp_5dB/audio \
        --splits train devel test --num_workers 16 --out bad_audio.txt
"""
import argparse
import json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from dataset import SlurpDataset, load_audio_robust


def check_one(job):
    root, fname = job
    try:
        path = SlurpDataset._find_audio(Path(root), fname)
    except FileNotFoundError:
        return (root, fname, "MISSING")
    try:
        wav, sr = load_audio_robust(path)
        if wav.numel() == 0:
            return (root, fname, "EMPTY")
    except Exception as e:
        return (root, fname, f"DECODE_ERROR: {str(e)[:200]}")
    return None


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--slurp_jsonl_dir", required=True)
    p.add_argument("--audio_roots", nargs="+", required=True)
    p.add_argument("--splits", nargs="+", default=["train", "devel", "test"])
    p.add_argument("--num_workers", type=int, default=8)
    p.add_argument("--out", default="bad_audio.txt")
    args = p.parse_args()

    for split in args.splits:
        fnames = []
        with open(Path(args.slurp_jsonl_dir) / f"{split}.jsonl") as f:
            for line in f:
                if line.strip():
                    fnames += [r["file"] for r in json.loads(line).get("recordings", [])
                               if r.get("file")]
        jobs = [(root, fn) for root in args.audio_roots for fn in fnames]
        with ProcessPoolExecutor(args.num_workers) as ex:
            bad = [r for r in ex.map(check_one, jobs, chunksize=64) if r is not None]

        print(f"[{split}] checked {len(jobs)} files, {len(bad)} bad")
        with open(args.out, "a") as f:
            for root, fname, why in bad:
                line = f"{split}\t{root}\t{fname}\t{why}"
                print("   ", line)
                f.write(line + "\n")


if __name__ == "__main__":
    main()
